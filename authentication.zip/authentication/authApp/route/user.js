// instance
const express =require("express");
// router
const router =express.Router();

// import
const{login,signup} = require("../controller/auth");
// handler
router.post("/login" ,login);
router.post("/signup",signup);

//import 
const {auth,isStudent,isAdmin} = require("../middlewares/Auth");
//protected routes
router.get("/student" ,auth,isStudent, (req,res) =>{
  // { "auth"--> authentication , "isStudent" ---> checked it have access or not  }--> protected route 
  res.json({
    success:true,
    message:"welcome to the protected route  for student",
  })
});

router.get("/admin" ,auth,isAdmin, (req,res) =>{
  res.json({
    success:true,
    message:"welcome to the protected route  for admin",
  })
});

// testing protected routes for single middleware
router.get("/test" ,auth ,(req,res) =>{
  res.json({
    success:true,
    message:"welcome to the protected route  for Test",
  })
});

//export
module.exports= router;


// middleware is function . 
// only those access whose are permissions