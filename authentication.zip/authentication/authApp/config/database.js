 //instance 
 const mongoose = require("mongoose");

 // load .env file 
  require("dotenv").config();
 // function 
 const connectWithDb = () =>{
mongoose.connect(process.env.MONGODB_URL, 
 // {
  //  useNewUrlParser:true,
  //  useUnifiedTopology:true
 // }
 // no need of above  dependencies from nodejs version 4.0 
).then(() =>{
 console.log("Connection Db Established")
}).catch( (err)=>{
  console.log("Db Connection Failed");
  console.error(err);
  process.exit(1);
})
 }

 module.exports = connectWithDb;