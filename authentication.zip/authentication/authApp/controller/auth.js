// import "bcrypt" library
const bcrypt =require("bcrypt");

// import jwt token 
const jwt =require("jsonwebtoken");

// import model
const User =require("../model/User");

// load the dotenv file due to jwt secret key
require("dotenv").config();

//signup 
exports.signup = async (req,res) =>{
  try{
    // get the data or fetch the data 
     const {name,email,password,role} = req.body;

     
      //check the User already exists or Not  by using emaail 
     const existingUser= await User.findOne({email});
    
     if(existingUser){
      return res.status(400).json({
        success:false,
        message:"User alreadyy Exists !!!",
     })
     }
      // secure password
      let hashedPassword;
      try{
        hashedPassword = await bcrypt.hash(password,10);
      
      }catch(err){
        return res.status(500).json({
          success:false,
          message:" Error in hashing password",
        });
      }

     // creating entry for user // using create 
     // you can used "save()" allso
      const user = await User.create({
        name,email,password:hashedPassword,role,
      });

     return res.status(200).json({
      success:true,
      message:" User creation Successfully!!!",
     });

  }catch(error){
    console.error(error);
   return  res.status(500).json({
    success:false,
    message:"User creation Failed !!!!",
        

   })
    
  }

}

// login 
exports.login = async (req,res) =>{
try{

  // data fetch 
  const {email,password} =req.body;

  // validation on email and password  
  if(!email || !password){
    return res.status(400).json({
      success:false,
      message:"please Fill the details carefully !!!"
    })
  }

  // check for registered users  //db me check kr rhe ho to "await" use krna 
  const user =await User.findOne({email});
  // if user is  not registered 
  if(!user){
    return res.status(401).json({
      success:false,
      message:" User is not registered please go fo signup "
    })
  }
   
  // this is payload created at runtime  
  const payload ={ 
    // key data // exact data used in token 
    email:user.email,
    id:user._id,
    role:user.role,
  }
  // verify the password and generate the JWT Token 
// we can compairing  the password by using "compare" function
// 2 parameter (normal password , hashedpasswoord(Encrypted)) 
  // bcrypt library have "compare" function 
  // hashing ka use bhi kr rhe hai isilye await use kr rhe 
  if(await bcrypt.compare(password,user.password)){
    // import jwt token above    // the above  "user" inside have encrypted password for comparing
    
    //password match
     //1> creation of jwt token  
    // ( payload , JWT_SECRET , Options/Callback function) ---> 3 parameters passed below
   // "sign" method to generting the jwt token 
    let token = jwt.sign (payload , process.env.JWT_SECRET
                , { //options
                  expiresIn:"2h",
                 }
              );
              user = user.toObject(); //user is converted into object ,why ? --> to saw the token in user .                // why ?
              //  token is inserted into user . 
             // --> to send with the res in the cookie i. why 
              
             user.token =token;// user created the another 'token' field in user and 
              // store the above "token " data.into user.token filed  (eg.token.user --> token= jwt.sign...........) 
              user.password =undefined;
              //why password undefined ?
              // when user send token . it send email as well as password also 
              // and it chances to hack by some one 
              // i why password undefined   

              const options ={
                //valid till (current time to next 3 days * 24 hr *60 min * 60 sec * 1000 milisecond)
                expires:new Date(Date.now() + 3 * 24*60*60*1000),
                httpOnly:true,
                // httponly means -- you can't access in the client side     
              }
               
              // creating the cookie 
              // 3 param (cookie name , cookie data , options)
             // you can use any name for cookie name 
              res.cookie("token" , token , options).status(200).json({
                success:true,
                token,
                user,
                message:"User logged in Successfully !!!",
              })
  }
else{
  // password do not match 
  return res.status(403).json({
    success:false,
    message:"Password Incorrect",
  })

}
} catch (error){
  console.log(error);
  return res.status(500).json({
    success:false,
    message:" Login Failed Please try again ",
  }
)
}

}

