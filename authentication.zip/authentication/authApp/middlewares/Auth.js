// auth,isStudent,isAdmin ----> protected routes

// import jwt 
const jwt =require("jsonwebtoken");
// import dotenv
require("dotenv").config();

//auth
exports.auth = (req,res,next) =>{
  try{
// what is next param ? --> it is used for redirect the next middleware if have then only .

// you can extract the token from three diff. parts 
//1>header  2>body 3> cookies
// where the token available extract from this place 

//extract the token .
 const token = req.body.token ;
 //  from cookie --> req.copokies.token;
  
 // token check present or not 
  if(!token){
    return res.status(401).json({
      success:true,
      message:"token missing ",
    })
  }
// token verifying  user authenticated or not  
// token  verifying by using "verify" method 
try{
  // 2 parameter passed. ( 1st token , 2nd JWT_SECRET key )
 const decode = jwt.verify(token,process.env.JWT_SECRET);
 console.log(decode);

 req.user =decode // decodde i.e payloaded data
   // why the . decode is stored inside the  req.user 
   //--> boz i check its Student or not , its Admin or not 
   //--> how ,
   //-->the role is presnt in payload 
   // payload is present in jwt   
 //         
  }catch(error){
    return res.status(401).json({
      success:true,
      message:"token is invalid  ",
    })
  }

  next(); // move to next protected routes eg.isStudent
} catch (error){
  return res.status(401).json({
    success:true,
    message:" Something went wrong !! while verifing the token  ",
  })
}
}
 //isStudent // role check // authorization
 exports.isStudent = (req,res,next) =>{
  try{
    // the above decode i.e payload is stored inside  in req.user ,  the req.user is means payload. and the payload have role key data. 
    if(req.user.role !== "Student"){ // check Student or not 
      return res.status(401).json({
        success:true,
        message:" This is protected routes for Student only !! ",
      });
    }
    next (); // move to next protected routes 

  }catch (error){
    return res.status(401).json({
      success:true,
      message:" Something went wrong !! while verifing the Student  ",
    })
  }
}
 //isAdmin // role check // authorization
exports.isAdmin = (req,res,next) =>{
  try{
    // the above decode i.e payload is stored inside  in req.user ,  the req.user is means payload. and the payload have role key data. 
    if(req.user.role !== "Admin"){ // check Admin or not 
      return res.status(401).json({
        success:true,
        message:" This is protected routes for Admin only !! ",
      });
    }
    next (); // move to next protected routes 

  }catch (error){
    return res.status(401).json({
      success:true,
      message:" Something went wrong !! while verifing the Admin  ",
    })
  }
}

 

 