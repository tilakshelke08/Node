// instance
const express = require("express");
const app =express();

// loaded .env file 
require("dotenv").config();

// PORT
const  PORT = process.env.PORT || 4000 ;
// middleware
app.use(express.json());

// mount
const user =require("./route/user");
app.use("api/v1",user);

// import database
const connectWithDb =require("./config/database");
// calliing databse 
connectWithDb();

// port started 
app.listen(PORT ,()=>{
 console.log(`Server is Started on ${PORT}`);
}
)

// default get method 
app.get("/get" , (req,res) =>{
  res.send(`<h1>This is Home Page </h1>`);
})



//<_______________________________________________>
//  all taking from previous videos. till blog app.
 // now we add authenications  and authorization handle  eg. signup and login 

 //1>
 // install  library  "bcrypt" -->   npm install bcrypt
 //2>
 // if u use jwt token 
 // install  "jwt token" ---> npm i jsonwebtoken
 