 
 // creating the mongoose instnce
  const { application } = require("express");
const mongoose = require("mongoose");

  require("dotenv").config(); 
  // above  line say that whatever are present in the "dotenv " 
// they are  move out to process object 

  // connect the mongoose with database 
function dbConnect () {
    mongoose.connect(
      process.env.DATABASE_URL , // this line for url  take from .env file
    
      // above both are must written  config. 
    ).then( () =>{
      console.log("dbConnection Established");

    }).catch( (error) =>{
      console.log(" Error Fouund");
      console.error(error.message);
      process.exit(1);
    }) 
  }
  // export 
  module.exports =dbConnect;

  // basically the database.js is used for  established the connection between the
   // application and databases 