
const express = require("express");
const app =express();

// load the confing from .env file 
require("dotenv").config();

const PORT =process.env.PORT || 3000;

// we need to passed the data i.e why used middleware 
// middleware to parse json request body
app.use(express.json());

// we  need routes  i.e import routes  for Todo API
 const todoRoutes = require("./routes/todos");

 // mount the todo API routes
 app.use("/api/v1" ,todoRoutes); // its work like  concatination of string 

 // start the server
 app.listen(PORT ,() =>{
  console.log('Server Started Successfully at ${PORT}');
 })

 // import  database
  const dbConnect =require("./config/database");
  // calling the databae function to connect with databse  
  dbConnect();

  // default routes
  app.get("/" , (req,res) =>{
    res.send('<h1>This is Home Page buddy </h1>');
  })
  
//<__________________________//<_________________________
// no need of below one  just write for understand 

//app.listen(3000, () =>{
//console.log(" server is running on port 3000");
//})

// no need of above  one  just write for understand 

//<__________________________//<__________________________
// you can use "nodemon" instead of  "node"  eg. node server.js
// if you used nodemon once you run the file its automatically re-rendered when you update any data you do not need again  and again to use command like node index.js to running the  backend application

// how to install nodemon ?
//--> npm i nodemon

// In the package.json file 
//--> In the Script 
// it delete "text" and written the  "start" and "dev"

// after written the above one you can use "npm run dev " instead of "node index.js"
 //<____________________________________________________________________>

 // creating  folder
 // config , controllers, models ,routes
 // and ".env" file   ( .env file means environment file )

 //In the .env file it mentioned url and port no

 // "127.0.0.1 " 
 // above value  is exactly  same as "localhost"
 // you can write this value or localhost both are same  

 // config folder is used for connecting the node with mongodb by using mongoose
 //IN config folder create one database.js file 
 //1> firstly install mongoose  in main folder i.e todoApp folder

 //  when we connect the momngoose with database we need url . 
 // to take the url from  .env file 
 //  how the  .env file is in the process object  ?
 //--> to  put  the .env file in to the  process object  we used " dotenv" library
 //  firstly install the  "dotenv" in todoApp

 //  how to install dotenv library ?
 // npm i dotenv 

 //<____________________________________________________________________>

 //In Model create one Todo.js file 
 //---> to creating the Schema i.e description or properties or atttributes

 //<____________________________________________________________________></____________________________________________________________________>

 // Controller
//-->  
 
