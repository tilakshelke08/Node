  // again crete the instance   of Schema 
 const mongoose = require("mongoose");

 // Wrrite the Schema  
 const todoSchema= new mongoose.Schema(
{
// properties or attributes
title :{
 type :String,
 required :true,
 maxLength:50,
},
description:{
  type :String,
  required :true,
  maxLength:50,
},
createdAt:{
  type :Date,
  required :true,
  default:Date.now(),
},
updatedAt:{
  type :Date,
  required :true,
  default:Date.now(),
}
}  

);

// export the todoSchema 
module.exports =mongoose.model("Todo" , todoSchema);