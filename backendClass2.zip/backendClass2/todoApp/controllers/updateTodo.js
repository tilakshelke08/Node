// we need model
//  import the model
const {Todo} = require("../models/Todo");

// define the routehandler

exports.updateTodo = async(req,res) =>{
    try{
      const {id} = req.param;
      // extract the tittle and desciption  from request body 
      const {title , description} = req.body;
      
      //create the new Todo object  and insert into the DB
      const todos = await Todo.findByIdAndUpdate(
        {_id:id},
        {title,description},
      {updatedAt:Date.now()},);
      // send aa json response with  success flag
    res.status(200).json(
        {
        success:true,
        data:todos,
        message:"updated Id Successfully",
        }
      );
    }catch(err){
       console.error(err);
       console.log(err);
       res.status(500).json(
        {
          success: false,
          data:"catching the internal server error",
          message:err.message,
        }
       )
    }
  }
   