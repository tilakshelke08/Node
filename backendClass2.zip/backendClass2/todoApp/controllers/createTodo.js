// we need model
//  import the model
const {Todo} = require("../models/Todo");

// define the routehandler

exports.createTodo = async(req,res) =>{
    try{
      // extract the tittle and desciption  from request body 
      const {title , description} = req.body;
      
      //create the new Todo object  and insert into the DB
      const response = await Todo.create({title,description});
      // send aa json response with  success flag
      res.status(200).json(
        {
        success:true,
        data:response,
        message:"Entry Created Successfully",
        }
      );
    }catch(err){
       console.error(err);
       console.log(err);
       res.status(500).json(
        {
          success: false,
          data:"catching the internal server error",
          message:err.message,
        }
       )
    }
  }
   