// we need model
//  import the model
const {Todo} = require("../models/Todo");

// define the routehandler

exports.deleteTodo = async(req,res) =>{
    try{
     const {id} = req.params.id;
      
      
      const response = await Todo.findByIdAndDelete({id});
      // send aa json response with  success flag
      res.status(200).json(
        {
        success:true,
        data:response,
        message:`delete id  ${id} successfullly`,
        }
      );
    }catch(err){
       console.error(err);
       console.log(err);
       res.status(500).json(
        {
          success: false,
          data:"catching the internal server error",
          message:err.message,
        }
       )
    }
  }
   