//  import the model
const {Todo} = require("../models/Todo");


exports.getTodo = async(req,res) =>{
  try{
  
    // find all todos by used find 
    const todos = await Todo.find({});
    // send aa json response with  success flag
    res.status(200).json(
      {
      success:true,
      data:todos,
      message:"todos Successfully fetched",
      }
    );
  }catch(err){
     console.error(err);
     console.log(err);
     res.status(500).json(
      {
        success: false,
        data:"Internal Error.....",
        message:err.message,
      }
     )
  }
}
 