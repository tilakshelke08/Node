const express = require("express");
const router = express.Router();

//<_________ below one is just wrtten for check  run or not _________>

// import  controller
const {dummylink} = require("../controllers/LikeController");

// why  above give you error 
//--> when you create the controller . you had creeated the "likeController"
// in the  Capital and after some time i rename the controller i. why 
// it give error 
// to  stooped th error  we can rewrite the controller path in import section as previous like ist time created name get

// you can see in the Controller , In the likecontroller  "l" is small 
//but In the import  path "Likecontroller"  is "L" is capital 


// import commentController
// mapping create 

router.get("/dummyrouter" ,dummylink);

//<_________ abobve one is written only for check running or not _____________>


//import
const { createElement } = require("../controllers/CommentController");
// for saved (comments)
router.post("/comments/create", createElement);

// import 
const { createPost} = require("../controllers/PostController");
// for saved (posts)
router.post("/posts/create", createPost);

// import 
const { getAllPosts} = require("../controllers/PostController");
// for saved (posts)
router.get("/posts", getAllPosts);


// import 
const {likePost } = require("../controllers/LikeController");
// for saved (posts)
router.post("/likes/like", likePost);

// import 
const {unlikePost } = require("../controllers/LikeController");
// for saved (posts)
router.post("/unlikes/unlike", unlikePost);


// exports 
module.exports = router; 