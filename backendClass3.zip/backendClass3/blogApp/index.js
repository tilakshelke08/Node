const express = require("express");
const app = express();


require("dotenv").config();

const PORT = process.env.PORT || 4000;

//middleware 
app.use(express.json());

// import route file 
const blog = require("./routes/blog")

// mount 
app.use("/api/v1",blog);

// import dadatbase
// and call database function  
const connectWithDb =require("./config/database");
connectWithDb();

// start the server 
app.listen(PORT , () =>{
  console.log(` Server is Successfully Running on Port ${PORT}`);
})

app.get("/" , (req,res) =>{
res.send('<h1> This is default Home  page!!!</h1>' );

})