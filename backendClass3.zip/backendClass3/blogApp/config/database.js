 const mongoose = require("mongoose");
 
require("dotenv").config();

 const connectWithDb =() =>{
  mongoose.connect(process.env.DATABASE_URL ,{
    useNewUrlParser:true,
    useUnifiedTopology:true,
  })
  .then(  console.log("DB connection Established !!"))
  .catch( (err) => {
    console.log(" Dbb connection Facing issue")
    console.log(err);
    process.exit(1);
  })

 }

module.exports= connectWithDb;