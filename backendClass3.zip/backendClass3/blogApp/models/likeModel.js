// import 
const mongoose =require("mongoose");

// route handler 

const likeSchema = new mongoose.Schema({
  post:{
    type: mongoose.Schema.Types.ObjectId,
    ref :"Post",
  },
  user:{
    type:String,
    required:true,

  },
});

module.exports = mongoose.model("Like",likeSchema);


//<________________________________________________>

// above post ,user
//-->
// In the like model  it have 2 module 
 // 1>post-->  In which post you like
 // 2>user-->   which user liked  
 


// firstly we write commemntmodel then likemodel and then postmodel
// post moddel need commentmodel  and likemodel array  i.why