// import 
const mongoose =require("mongoose");

// route handler 

const postSchema = new mongoose.Schema({
  title:{
    type: String,
    required :true,
  },
  body:{
    type:String,
    required:true,

  },
  likes:[{ // likes is an arr[]
 type: mongoose.Schema.Types.ObjectId,
 ref :"Like", // this ref. like is used in likemodel 
  }],
  comments:[{
    type: mongoose.Schema.Types.ObjectId,
    ref:"Comment" // this ref. commnet is used in commentmodel 
  }],
});

module.exports = mongoose.model("Post",postSchema);
// why we wrrite the ref = "Post" in likemodel and commentmodel 
//--> Postmodel ko export krna tha Post string se . i.why 

//<________________________________________________>

// above title ,body ,likes []arr , comment []arr
//-->
// In the like model  it have 2 module 
 // 1>title-->   which title in post 
 // 2>body-->   which post is posted  
 // 3>like []arr  --> ref. like is used in likemodel 
// 4>comment []arr ---> ref. comment is used in commentmodel 

