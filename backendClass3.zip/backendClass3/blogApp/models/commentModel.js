// import 

const mongoose =require("mongoose");

// route handler

const commentSchema  = new mongoose.Schema({
  post :{
   type: mongoose.Schema.Types.ObjectId,
   ref :"Post", // reference to the post model 
  },
  user:{
    type:String,
    required : true,

  },
  body:{
    type:String,
    required:true,

  }

});

//export
module.exports =  mongoose.model("Comment" ,commentSchema);


//<________________________________________________>

// abive post ,user and body 
//-->
// In the comment model  it have 3 module 
 // 1>post-->  In which post you commented
 // 2>user-->   which user commented 
 // 3>body --> which comment you commented.


 // above is similar  for postmodel and likmodel
 // but some chamges