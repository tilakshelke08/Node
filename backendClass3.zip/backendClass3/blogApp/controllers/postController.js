// import postmode 

const Post = require("../models/postModel");

exports.createPost = async (req,res) =>{
  try{
// extract data 
    const {title,body} = req.body;
    // creting tthe object 
    const post =  new Post({
      title,body,

    });
    // apply saave function or inserting into dataaabse 
     const savePost = await post.save();

     res.json({
      post:savePost,
     });
 
  }catch(error){
    return res.status(500).json({
      error:" Error faced during creting the Object ",
    });
  }
}

exports.getAllPosts =async(req,res) =>{
  try{

   //  const posts =  await Post.find();  // if you want only Id.  
   //code finished.

   // if you want all likes and comments
  const posts = await Post.find().populate("likes").populate("comments").exec();
   res.json({
    posts,
   })
  }catch(error){

    return res.status(500).json({
      error:"getting error due to ffetching issue",
    })
  }
}