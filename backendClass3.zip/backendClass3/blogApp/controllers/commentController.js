// import  models
 const Post = require("../models/postModel");
 const Comment = require("../models/commentModel");

 // business logic 

 exports.createElement = async (req,res) =>{
  try{
    
    // fetch the data  from reqq. body
     const {post , user, body} = req.body;

     // create the comment object (create the object in small letter alwaays )
      const comment = new Comment ({ // 1st comment is 'obj" written in small letters and after the new word 2nd Comment  1st letter always capital  // you u not apply this logic you will get error 
        post,user,body
      });

      // save the new Comment into the database 
      const savedComment =await comment.save(); // "save:" is exactly same as "create" to inserting the data into database .  // this is 1st comment object (small letter)
                                // above Comment is Obj.
      
     // find the post by Id , add the new comment  to its comment array
const updatedPost= await Post.findByIdAndUpdate(post , {$push : {comments:savedComment._id}}, {new:true}) // what is new - true means :-- it means after completeimg the push the id or completing any woork it return the updated documents .
                                   .populate("comments")//populate the Comment array with  comment documents 
                                   .exec(); // above populate comments post model walla hai  same likhoge tabhi work krega 
                          //  by using the above post(left side of $push) it searches Id   // (right  side of $push ) comments ke ander Id update krna chahta hu (ye comments post model ka ander wala hai ) 
                            // $ push is update operator (used for update the entry )
                          // $ pull is delete or remove operator (used for remove /delete the entry )
    // if u want the original document then used populate if u want only id then dont used popullates . 
    
                          res.json({
        post:updatedPost,
       })
    }catch(error){
 return res.status(500).json({
  error:" error whie creating the Comments "
 });
  }
 };