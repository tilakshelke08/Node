

exports.dummylink =(req,res) =>{
  res.send('<h1>this is an home page </h1>');
}


// <_______________ all above just ewrite for  running check ______>

//<______likecontroller below one _____________>

// import 
const Post = require("../models/postModel");
const Like =require("../models/likeModel");

// like a post 
exports.likePost = async (req,res) =>{
 try{

   //extract the data 
  const {post,user} =req.body;

  // create the obj 

  const like = new Like({
    post,user,
  });
  const savedLike = await like.save();

   //update the post coontroller
const updatedPost= await Post .findByIdAndUpdate(post , {$push : {likes:savedLike._id}}, {new:true}) // what is new - true means :-- it means after completeimg the push the id or completing any woork it return the updated documents .
.populate("likes")//populate the Comment array with  comment documents 
.exec(); // above populate comments post model walla hai  same likhoge tabhi work krega 
//  by using the above post(left side of $push) it searches Id   // (right  side of $push ) comments ke ander Id update krna chahta hu (ye comments post model ka ander wala hai ) 
// $ push is update operator (used for update the entry )
// $ pull is delete or remove operator (used for remove /delete the entry )
res.json({
  post:updatedPost,
})

 }catch(error){
  return res.status(500).json({
    error: "Internall Server Error",
  });
 }

}


//unlike post
exports.unlikePost = async (req,res) =>{
  try{
 
    //extract the data 
   const {post,like} =req.body;
 
  

   //find amnd dellete tthe liked collections
   const deletedLike = await Like.findOneAndDelete({post:post ,_id:like});
 
    //update the post coontroller
 const deletedPost= await Post .findByIdAndDelete(post , {$pull : {likes:deletedLike._id}}, {new:true}) // what is new - true means :-- it means after completeimg the push the id or completing any woork it return the updated documents .
 .populate("likes")//populate the Comment array with  comment documents 
 .exec(); 
 res.json({
   post:deletedPost,
 })
 
  }catch(error){
   return res.status(500).json({
     error: "Internall Server Error",
   });
  }
 
 }